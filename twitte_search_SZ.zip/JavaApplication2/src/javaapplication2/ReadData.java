/*
 * This file is for reading the data in .json file and keep then into twitterADT list.
 */
package javaapplication2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class ReadData {
	private ArrayList<twitterADT> userList;
	
	public ReadData(ArrayList<twitterADT> userList) {
		this.userList = userList;
	}

	
	/*
	 * this is for single file loading. take the path and return a list.
	 */
	public ArrayList<twitterADT> LoadUsers(String path) throws IOException, ParseException {
		String date = null;
		String tag = null;
		String language = null;
		String time = null;
		String region = null;
		long likenumber = 0;
		
		Map map = new HashMap();
		map.put("JAN", "01");
		map.put("FEB", "02");
		map.put("MAR", "03");
		map.put("APR", "04");
		map.put("MAY", "05");
		map.put("JUN", "06");
		map.put("JUL", "07");
		map.put("AUG", "08");
		map.put("SEP", "09");
		map.put("OCT", "10");
		map.put("NOV", "11");
		map.put("DEC", "12");
		
		File ff = new File(path);
		BufferedReader reader = null;
		JSONObject objects,tagArrayObject;
                //String tag[]=new String[10];
		try {
			reader = new BufferedReader(new FileReader(ff));
			String temp = null;
			
			while((temp = reader.readLine()) != null) {
                            objects = (JSONObject) new JSONParser().parse(temp);
                            if(     objects.containsKey("user")
                                    &&objects.containsKey("entities")
                                    ){
                                
                                //get language
				JSONObject qwe = (JSONObject) objects.get("user");
				language = (String)qwe.get("lang");
				
                                //get hashTag
				tagArrayObject = (JSONObject)objects.get("entities");
                                tag=(tagArrayObject.get("hashtags")).toString();
                                if(tag.length()>2){
                                    tag=tag.substring(tag.indexOf("text")+7, tag.indexOf("\"}"));
                                }


				//get create time
				String da = (String)objects.get("created_at");
				String []da1 = da.split(" ");
				date = da1[5] + map.get(da1[1].toUpperCase()) + da1[2];
				time = da1[3].substring(0, 2) + da1[3].substring(3, 5) + da1[3].substring(6);
				
                                
                                //get likenumber
				likenumber = (Long)qwe.get("favourites_count");
				
                                
				if((String)qwe.get("time_zone")==null)	region ="Unknown";
                                else region = (String)qwe.get("time_zone");
				

                                if(tag.length()>2){
                                    twitterADT element = new twitterADT(date, tag, language, time, region, likenumber);
                                    userList.add(element);
                                }
                            }
			}
			
		}
		catch (FileNotFoundException e) { e.printStackTrace(); }
		return userList;
	}
	
	/*
	 * this is for combination of files and folders loading, take a particular date and return a list.
	 */
	public ArrayList<twitterADT> ReadEngine(String thepath)  throws IOException, ParseException {

		this.userList.clear();
        this.userList = new ArrayList<twitterADT>();

		String year = thepath.substring(0,4);
		String month = thepath.substring(4, 6);
		String day = thepath.substring(6);
		String datapath = "src/data/" + year + "/" + month + "/" + day;
		File insidedate = new File(datapath);
		if (!insidedate.exists()) {
			insidedate.mkdir();
		}else {
			File[] listt = insidedate.listFiles();
			for (int i=0;i<listt.length;i++) {
				if (listt[i].isDirectory()) {
					String temp = listt[i].getName();
					File subfile = new File(datapath + "/" + temp);
					File[] sublist = subfile.listFiles();
					for (int j=0;j<sublist.length;j++) {
						String fileName = sublist[j].getName();
						if(!fileName.substring(fileName.lastIndexOf(".")).equalsIgnoreCase(".json"))
							continue;
		                LoadUsers(datapath + "/" + temp + "/" + fileName);
					}
				}
				else if (listt[i].isFile()){
		                String fileName = listt[i].getName();
		                if(!fileName.substring(fileName.lastIndexOf(".")).equalsIgnoreCase(".json"))
							continue;
		                LoadUsers(datapath + "/" + fileName);            
				}	
			}
		}
		return this.userList;
	}
	
	



	

	public static void main(String args[]) throws IOException, ParseException{
		ArrayList<twitterADT> outo = new ArrayList<twitterADT>();
		ReadData qwe = new ReadData(outo);
		outo = qwe.ReadEngine("20110930");
		//outo = qwe.LoadUsers("src/data/2011/09/30/02/00.json");
		System.out.println(outo.size());
            
	}
            
}
