package javaapplication2;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

public class tesing {
	public static String assistantfunction()  throws IOException, ParseException {
File imgFile = new File("src/data/9");
		
		// no path ,then build a empty one
		if (!imgFile.exists()) {
			imgFile.mkdirs();
		}else {
			// save
			System.out.println(imgFile.isDirectory());
			File[] listt = imgFile.listFiles();//��ȡ�ļ����ڵ������ļ���

				//���  //ǳ���� Arrays.asList(list)
			System.out.println(listt.length);
			for (int i=0;i<listt.length;i++) {
				if (listt[i].isDirectory()) {
					String temp = listt[i].getName();
					System.out.println(temp);
					File subfile = new File("src/data/9/" + temp);
					File[] sublist = subfile.listFiles();
					for (int j=0;j<sublist.length;j++) {
						String fileName = sublist[j].getName();
		                System.out.println("Ŀ¼��" + fileName);
					}
				}
				else if (listt[i].isFile()){
					if (listt[i].isFile()) {
		                String fileName = listt[i].getName();
		                System.out.println("�ļ���" + fileName);                
		            }
		            
		            if (listt[i].isDirectory()) {
		                String fileName = listt[i].getName();
		                System.out.println("Ŀ¼��" + fileName);        
		            }
				}	
			}
		}
		String temp = null;
		return temp;
	}

	public static void mainone(String pathname) throws IOException, ParseException {
		/*File imgFile = new File("src/data/9");
		
		// ͼƬ�ļ���·�������ڣ��򴴽�
		if (!imgFile.exists()) {
			imgFile.mkdirs();
		}else {
			// ����ͼƬ����ֱ�ӻ�ȡ
			System.out.println(imgFile.isDirectory());
			File[] listt = imgFile.listFiles();//��ȡ�ļ����ڵ������ļ���

				//���  //ǳ���� Arrays.asList(list)
			System.out.println(listt.length);
			for (int i=0;i<listt.length;i++) {
				if (listt[i].isDirectory()) {
					String temp = listt[i].getName();
					System.out.println(temp);
					File subfile = new File("src/data/9/" + temp);
					File[] sublist = subfile.listFiles();
					for (int j=0;j<sublist.length;j++) {
						String fileName = sublist[j].getName();
		                System.out.println("Ŀ¼��" + fileName);
					}
				}
				else if (listt[i].isFile()){
					if (listt[i].isFile()) {
		                String fileName = listt[i].getName();
		                System.out.println("�ļ���" + fileName);                
		            }
		            
		            if (listt[i].isDirectory()) {
		                String fileName = listt[i].getName();
		                System.out.println("Ŀ¼��" + fileName);        
		            }
				}	
			}
		}*/
		
		String date = null;
		String tag = null;
		String language = null;
		String time = null;
		String region = null;
		long likenumber = 0;
		
		Map map = new HashMap();
		map.put("JAN", "01");
		map.put("FEB", "02");
		map.put("MAR", "03");
		map.put("APR", "04");
		map.put("MAY", "05");
		map.put("JUN", "06");
		map.put("JUL", "07");
		map.put("AUG", "08");
		map.put("SEP", "09");
		map.put("OCT", "10");
		map.put("NOV", "11");
		map.put("DEC", "12");
		
		BufferedReader reader = null;
		JSONObject objects,tagArrayObject;
		File qwee;
		try {
			for(int i = 1;i<61;i++) {
				qwee = new File(pathname);
				System.out.println("got you bitch :  " + i);
				reader = new BufferedReader(new FileReader(qwee));
				
				String temp = null;
				
				while((temp = reader.readLine()) != null) {
	                            objects = (JSONObject) new JSONParser().parse(temp);
	                            if(     objects.containsKey("user")
	                                    &&objects.containsKey("entities")
	                                    ){
	                                
	                                //get language
					JSONObject qwe = (JSONObject) objects.get("user");
					language = (String)qwe.get("lang");
					
	                                //get hashTag
					tagArrayObject = (JSONObject)objects.get("entities");
	                                tag=(tagArrayObject.get("hashtags")).toString();
	                                if(tag.length()>2){
	                                    tag=tag.substring(tag.indexOf("text")+7, tag.indexOf("\"}"));
	                                }


					//get create time
					String da = (String)objects.get("created_at");
					String []da1 = da.split(" ");
					date = da1[5] + map.get(da1[1].toUpperCase()) + da1[2];
					time = da1[3].substring(0, 2) + da1[3].substring(3, 5) + da1[3].substring(6);
					
	                                
	                                //get likenumber
					likenumber = (Long)qwe.get("favourites_count");
					
	                                
					if((String)qwe.get("time_zone")==null)	region ="Unknown";
	                                else region = (String)qwe.get("time_zone");
					
	                                if(tag.length()>2){
	                                    twitterADT element = new twitterADT(date, tag, language, time, region, likenumber);
	                                    System.out.println("Date: "+element.getDate());
	                                    System.out.println("Lang: "+element.getLanguage());
	                                    System.out.println("Region: "+element.getRegion());
	                                    System.out.println("tag: "+element.getTag());
	                                    //System.out.println("tag: "+tweet.get(i).getTag().substring(2,-2));
	                                    System.out.println("Time: "+element.getTime());
	                                    System.out.println("rank: "+element.getLikeNum());
	                                    System.out.println();
	                                }
	                            }
				}
			}
		}
		catch (FileNotFoundException e) {System.out.println("hola");}
	}
	
	public static void main(String[] args) throws IOException, ParseException {
		String thepath = "20110927";
		///////////////////////////////////////////
		ArrayList<twitterADT> tweet;
        tweet = new ArrayList<twitterADT>();
        ReadData reading = new ReadData(tweet);

		String year = thepath.substring(0,4);
		String month = thepath.substring(4, 6);
		String day = thepath.substring(6);
		String datapath = "src/data/" + year + "/" + month + "/" + day;
		File insidedate = new File(datapath);
		if (!insidedate.exists()) {
			insidedate.mkdir();
		}else {
			File[] listt = insidedate.listFiles();
			for (int i=0;i<listt.length;i++) {
				if (listt[i].isDirectory()) {
					String temp = listt[i].getName();
					File subfile = new File(datapath + temp);
					File[] sublist = subfile.listFiles();
					for (int j=0;j<sublist.length;j++) {
						String fileName = sublist[j].getName();
						if(!fileName.substring(fileName.lastIndexOf(".")).equalsIgnoreCase(".json"))
							continue;
		                reading.LoadUsers(datapath + "/" + fileName);
					}
				}
				else if (listt[i].isFile()){
		                String fileName = listt[i].getName();
		                if(!fileName.substring(fileName.lastIndexOf(".")).equalsIgnoreCase(".json"))
							continue;
		                reading.LoadUsers(datapath + "/" + fileName);            
				}	
			}
		}
		/////////////////////////
		for(int i=0;i<tweet.size();i++){
            System.out.println("Date: "+tweet.get(i).getDate());
            System.out.println("Lang: "+tweet.get(i).getLanguage());
            System.out.println("Region: "+tweet.get(i).getRegion());
            System.out.println("tag: "+tweet.get(i).getTag());
            //System.out.println("tag: "+tweet.get(i).getTag().substring(2,-2));
            System.out.println("Time: "+tweet.get(i).getTime());
            System.out.println("rank: "+tweet.get(i).getLikeNum());
            System.out.println();
        }
        System.out.println(tweet.size());
    }

}
