package javaapplication2;

public class sort {
	private static twitterADT[] aux;
	public static void sortt(twitterADT[] a) {
		aux = new twitterADT[a.length];
		sortt(a,0,a.length-1);
	}
	
	private static void sortt(twitterADT[] a, int lo, int hi) {
		if (hi < lo) {
			return;
		}
		int mid = lo + (hi-lo)/2;
		sortt(a,lo, mid);
		sortt(a, mid+1, hi);

		merge(a, lo, mid, hi);
	}

	private static void merge(twitterADT[] a, int lo, int mid, int hi) {
		int i = lo, j = mid+1;
		for (int k =lo;k<=hi;k++) {
			aux[k]=a[k];
		}
		for (int k =lo;k<=hi;k++)
			if (i>mid)
				a[k] = aux[j++];
			else if (i>hi)
				a[k] = aux[i++];
			else if (aux[j].compareTo(aux[i])<0)
				a[k] = aux[j++];
			else
				a[k] = aux[i++];
	}

}
